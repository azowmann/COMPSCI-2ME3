public class ShapeArgumentException extends Exception{

    public ShapeArgumentException(String message) {
        super(message);
    }
}